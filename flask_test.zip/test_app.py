from flask import Flask, render_template, request, redirect, url_for, session, jsonify
import secrets
import sqlite3
import hashlib

app=Flask(__name__,static_folder='assets', template_folder='template')

app.secret_key = secrets.token_hex(16)  # Generate a 16-byte (32-character) random string

##### Table Creation
def create_table():
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users
                 (id INTEGER PRIMARY KEY, username TEXT UNIQUE, password TEXT)''')
    conn.commit()
    # conn.close()

    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS cart
                 (id INTEGER PRIMARY KEY, username TEXT, item_name TEXT, quantity INTEGER, price TEXT)''')
    conn.commit()
    conn.close()

    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS wishlist
                 (id INTEGER PRIMARY KEY, username TEXT, item_name TEXT, quantity INTEGER, price TEXT)''')
    conn.commit()
    conn.close()

    
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS items
                 (item_id INTEGER PRIMARY KEY,
                 item_name TEXT,
                 old_price REAL,
                 new_price REAL,
                 star INTEGER,
                 description TEXT,
                 image_path TEXT,
                 tag TEXT,
                 timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')
    conn.commit()
    conn.close()

def insert_item_data():
    # username = session['username']
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    # Sample insert statements
    items = [
        ('Floral Print Buttoned1', 500.0, 450.0, 4, 'Beautiful floral dress', 'p1.jpg', 'dress', '2023-01-01 12:00:00'),
        ('Floral Print Buttoned2', 300.0, 250.0, 3, 'Stylish striped shirt', 'p2.jpg', 'shirt', '2023-01-02 12:00:00'),
        ('Floral Print Buttoned3', 400.0, 350.0, 5, 'Comfortable jeans for everyday wear', 'p3.jpg', 'jeans', '2023-01-03 12:00:00')
    ]
    c.executemany("INSERT INTO items (item_name, old_price, new_price, star, description, image_path, tag, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?, ?)", items)
    conn.commit()
    conn.close()

############ FUNCTIONS
# Function to register user
def register_user(username, password):
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, hashlib.sha256(password.encode()).hexdigest()))
    conn.commit()
    conn.close()

# Functions 
def authenticate_user(username, password):
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE username = ? AND password = ?", (username, hashlib.sha256(password.encode()).hexdigest()))
    user = c.fetchone()
    conn.close()
    return user

def get_items():
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute("SELECT * FROM items")
    items = c.fetchall()
    conn.close()
    return items

def get_item_by_id(item_id):
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute("SELECT * FROM items WHERE item_id = ?", (item_id,))
    item = c.fetchone()  # Fetch the first row
    conn.close()
    return item

def get_cart_items_sum():
    username = session['username']
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute("SELECT sum(price) FROM cart where username = ?", (username,))
    count = c.fetchone()[0]
    conn.close()
    return count

# Function to add item to cart
def add_to_cart(item_name, quantity, price):
    username = session['username']
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute("INSERT INTO cart (item_name, username, quantity, price) VALUES (?, ?, ?, ?)", (item_name, username, quantity, price))
    conn.commit()
    conn.close()

def add_to_wishlist(item_name, quantity, price):
    username = session['username']
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute("INSERT INTO wishlist (item_name, username, quantity, price) VALUES (?, ?, ?, ?)", (item_name, username, quantity, price))
    conn.commit()
    conn.close()

# Function to get cart items
def get_cart_items():
    username = session['username']
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute("SELECT * FROM cart where username = ?", (username,))
    items = c.fetchall()
    # print(items)
    conn.close()
    return items

def get_wishlist_items():
    username = session['username']
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute("SELECT * FROM wishlist where username = ?", (username,))
    items = c.fetchall()
    # print(items)
    conn.close()
    return items

def get_cart_items_count():
    username = session['username']
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute("SELECT COUNT(*) FROM cart where username = ?", (username,))
    count = c.fetchone()[0]
    conn.close()
    return count

# Function to add item to cart
def remove_from_cart(item_id):
    username = session['username']
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute("DELETE FROM cart WHERE id = ?", (item_id,))
    conn.commit()
    conn.close()

############ ROUTES
@app.route('/')
def home():
    if 'username' in session:
        cart_count = get_cart_items_count()
        cart_sum = get_cart_items_sum()
        return render_template('home.html', username=session['username'], cart_count=cart_count, cart_sum=cart_sum)
    return render_template('home.html', cart_count=0, cart_sum=0)

@app.route('/category')
def category():
    items = get_items()
    cart_count = get_cart_items_count()
    cart_sum = get_cart_items_sum()
    return render_template('category.html', items=items, cart_count=cart_count, cart_sum=cart_sum)

@app.route('/wishlist')
def wishlist():
    if 'username' in session:
        items = get_wishlist_items()
        return render_template('my-wishlist.html', items=items)
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():

    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = authenticate_user(username, password)
        if user:
            session['username'] = username
            return redirect(url_for('home'))
        else:
            return render_template('login.html', error='Invalid username or password.')
    return render_template('login.html', cart_count=0, cart_sum=0)

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('home'))

@app.route('/profile')
def profile():
    if 'username' in session:
        return render_template('profile.html', username=session['username'])
    return redirect(url_for('login'))
    
@app.route('/checkout')
def checkout():
    if 'username' in session:
        cart_count = get_cart_items_count()
        cart_sum = get_cart_items_sum()
        return render_template('checkout.html', username=session['username'], cart_count=cart_count, cart_sum=cart_sum)
    return redirect(url_for('login'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        register_user(username, password)
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/add_to_cart', methods=['POST'])
def add_to_cart_route():
    item_name = request.form['item_name']
    quantity = int(request.form['quantity'])    
    price = request.form['price']
    add_to_cart(item_name, quantity,price)
    cart_count = get_cart_items_count()
    return jsonify({'cart_count': cart_count})
    # return redirect(url_for('wishlist'))

@app.route('/add_to_wishlist', methods=['POST'])
def add_to_wishlist_route():
    item_name = request.form['item_name']
    quantity = int(request.form['quantity'])    
    price = request.form['price']
    add_to_wishlist(item_name, quantity,price)
    cart_count = get_wishlist_items_count()
    return jsonify({'cart_count': cart_count})
    # return redirect(url_for('wishlist'))


@app.route('/remove_from_cart', methods=['POST'])
def remove_from_cart_route():
    item_id = request.form['item_id']
    # quantity = int(request.form['quantity'])    
    # price = request.form['price']
    remove_from_cart(item_id)
    cart_count = get_cart_items_count()
    print(cart_count)
    return jsonify({'cart_count': cart_count})
    # return redirect(url_for('wishlist'))

@app.route('/cart')
def cart():
    if 'username' in session:
        items = get_cart_items()
        cart_count = get_cart_items_count()
        cart_sum = get_cart_items_sum()
        return render_template('shopping-cart.html', items=items, cart_count=cart_count, cart_sum=cart_sum)
    return redirect(url_for('login'))

@app.route('/detail.html')
def detail():
    item_id = request.args.get('item_id')
    cart_count = get_cart_items_count()
    cart_sum = get_cart_items_sum()
    if item_id:
        item = get_item_by_id(item_id)
        if item:
            return render_template('detail.html', item=item, cart_count=cart_count, cart_sum=cart_sum)
    return 'Item not found or invalid item ID'



if __name__ == '__main__':
    create_table()
    insert_item_data()
    app.run(host='0.0.0.0', port=81, debug=True)